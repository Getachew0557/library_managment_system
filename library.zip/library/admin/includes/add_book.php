<?php
    if(isset($_POST['create_book'])) {
       $book_title          = mysqli_real_escape_string($connection, trim($_POST['book_title']));
       $book_category_id    = mysqli_real_escape_string($connection, trim($_POST['book_category_id']));
       $book_user           = $_SESSION['username']; // User Added
       $book_author         = mysqli_real_escape_string($connection, trim($_POST['book_author']));
       $book_status         = mysqli_real_escape_string($connection, trim($_POST['book_status']));

       $book_image          = $_FILES['image']['name'];
       $book_image_tmp      = $_FILES['image']['tmp_name'];

       $book_tags           = mysqli_real_escape_string($connection, trim($_POST['book_tags']));
       $book_content        = mysqli_real_escape_string($connection, trim($_POST['book_content']));

       $book_date           = date('d-m-y');

       move_uploaded_file($book_image_tmp, "../images/$book_image");

       $query = "INSERT INTO books(book_category_id, book_title, book_author, book_user, book_date, book_image, 
                    book_content, book_tags, book_status) VALUES($book_category_id, 
                    '$book_title', '$book_author', 
                    '$book_user', now(), '$book_image', '$book_content', '$book_tags',  
                    '$book_status')";

        $result = mysqli_query($connection, $query);

        confirmQuery($result);

        $the_get_book_id = mysqli_insert_id($connection);

        echo "<p class='text-center text-success bg-success'>Post Created. <a href='../book.php?p_id=$the_get_book_id'> View Books</a> Or <a href='books.php'>Edit More Books</a></p>";
    }
?>
<form action="" method="post" enctype="multipart/form-data">  
    <div class="form-group">
        <label for="book_title">Post Title</label>
        <input type="text" name="book_title" class="form-control">
    </div>

    <div class="form-group">
        <label for="post_category">Post Category</label>
        <select name="book_category_id" class="form-control">
            <?php
                $query = "SELECT * FROM categories";
                $result = mysqli_query($connection, $query);

                confirmQuery($result);

                while($row = mysqli_fetch_array($result)) {
                    $cat_id = $row['cat_id'];
                    $cat_title = $row['cat_title'];
                    
                    echo "<option value='$cat_id'>$cat_title</option>";
                }
            ?>
        </select>
    </div>

    <div class="form-group">
        <label for="book_author">Post Author</label>
        <input type="text" name="book_author" class="form-control">
    </div>

    <div class="form-group">
        <label for="book_status">Post Status</label>
        <select name="book_status" class="form-control">
            <option value="draft">Select Options</option>
            <option value="published">Publish</option>
            <option value="draft">Draft</option>
        </select>
    </div>

    <div class="form-group">
        <label for="book_image">Post Image</label>
        <input type="file" name="image" class="form-control">
    </div>

    <div class="form-group">
        <label for="book_tags">Post Tags</label>
        <input type="text" name="book_tags" class="form-control">
    </div>

    <div class="form-group">
        <label for="book_content">Post Content</label>
        <textarea name="book_content" class="form-control" cols="30" rows="10"></textarea>
    </div>

    <div class="form-group">
        <input type="submit" value="Publish Book" name="create_book" class="btn btn-primary">
    </div>
</form>