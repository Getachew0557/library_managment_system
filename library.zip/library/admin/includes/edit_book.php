<?php
    if(isset($_GET['p_id'])) {
        $the_get_book_id = mysqli_real_escape_string($connection, trim($_GET['p_id']));

        $query = "SELECT * FROM books WHERE book_id = $the_get_book_id";
        $result = mysqli_query($connection, $query);

        while($row = mysqli_fetch_array($result)) {
            $book_id            = $row['book_id'];
            $book_category_id   = $row['book_category_id'];
            $book_title         = $row['book_title'];
            $book_user          = $row['book_user'];
            $book_author        = $row['book_author'];
            $book_date          = $row['book_date'];
            $book_image         = $row['book_image'];
            $book_content       = $row['book_content'];
            $book_tags          = $row['book_tags'];
            $book_comment_count = $row['book_comment_count'];
            $book_status        = $row['book_status'];
        }
    }

    if (isset($_POST['update_book'])) {
       $book_title          =  mysqli_real_escape_string($connection, trim($_POST['book_title']));
       $book_category_id    =  mysqli_real_escape_string($connection, trim($_POST['book_category_id']));
       $book_status         =  mysqli_real_escape_string($connection, trim($_POST['book_status']));

       $book_image          =  $_FILES['image']['name'];
       $book_image_tmp      =  $_FILES['image']['tmp_name'];

       $book_tags           =  mysqli_real_escape_string($connection, trim($_POST['book_tags']));
       $book_content        =  mysqli_real_escape_string($connection, trim($_POST['book_content']));

       move_uploaded_file($book_image_tmp, "../images/$book_image");

       if(empty($book_image)) {
            $query = "SELECT * FROM books WHERE book_id = $the_get_book_id";
            $select_image = mysqli_query($connection, $query);

            while($row = mysqli_fetch_array($select_image)) {
                $book_image = $row['book_image'];
            }
       }


       $query = "UPDATE books SET book_category_id = $book_category_id, book_title = '$book_title', 
                book_user = '$book_user', book_date = now(), book_image = '$book_image', 
                book_content = '$book_content', book_tags = '$book_tags', 
                book_comment_count = $book_comment_count, book_status = '$book_status' 
                WHERE book_id = $the_get_book_id";

        $result = mysqli_query($connection, $query);

        confirmQuery($result);

        echo "<p class='text-center text-success bg-success'>Book Updated Successfully. <a href='../book.php?p_id=$the_get_book_id'> View Book</a> Or <a href='books.php'>Edit More Books</a></p>";
    }
?>

<form action="" method="post" enctype="multipart/form-data">
    
    <div class="form-group">
        <label for="book_title">Book Title</label>
        <input type="text" name="book_title" class="form-control" value="<?php echo $book_title; ?>">
    </div>

    <div class="form-group">
        <label for="book_category">Book Category</label>
        <select name="book_category_id" class="form-control">
            <?php
                $query = "SELECT * FROM categories";
                $result = mysqli_query($connection, $query);

                confirmQuery($result);

                while($row = mysqli_fetch_array($result)) {
                    $cat_id = $row['cat_id'];
                    $cat_title = $row['cat_title'];

                    if($cat_id == $book_category_id) {
                        echo "<option selected value='$cat_id'>$cat_title</option>";
                    } else {
                        echo "<option value='$cat_id'>$cat_title</option>";
                    }
                }
            ?>
        </select>
    </div>

    <div class="form-group">
        <label for="book_auhtor">book Author</label>
        <input type="text" name="book_author" class="form-control" value="<?php echo $book_author; ?>">
    </div>

    <div class="form-group">
        <label for="book_category">Book Status</label>
        <select name="book_status" class="form-control">
            <option value='<?php echo $book_status; ?>'><?php echo $book_status; ?></option>
            <?php
                if($book_status == "published") {
                    echo "<option value='draft'>Draft</option>";
                } else {
                    echo "<option value='published'>published</option>";
                }
            ?>
        </select>
    </div>

    <div class="form-group">
        <input type="file" name="image" class="form-control">
        <img class='img-responsive' width = "200" src="../images/<?php echo $book_image; ?>" alt="">
    </div>

    <div class="form-group">
        <label for="book_tags">Book Tags</label>
        <input type="text" name="book_tags" class="form-control" value="<?php echo $book_tags; ?>">
    </div>

    <div class="form-group">
        <label for="book_content">Book Content</label>
        <textarea name="book_content" class="form-control" cols="30" rows="10"><?php echo str_replace('\r\n', '<br/>', $book_content); ?></textarea>
    </div>

    <div class="form-group">
        <input type="submit" value="Edit Book" name="update_book" class="btn btn-primary">
    </div>
</form>