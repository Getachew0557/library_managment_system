<?php include("includes/header.php"); ?>

    <div id="wrapper">
        <?php include("includes/navigation.php"); ?> <!-- Navigation -->

        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row"><!-- Page Heading -->
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome To Admin
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                        <?php
                            // Displaying pages based on condition
                            if (isset($_GET['source'])) {
                                $source = $_GET['source'];
                            } else {
                                $source = "";
                            }

                            switch ($source) {
                                case 'add_book':
                                    include("includes/add_book.php");
                                    break;
                                
                                case 'edit_book':
                                    include("includes/edit_book.php");
                                    break;
                                
                                default:
                                    include("includes/view_all_books.php");
                                    break;
                            } ?>
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div><!-- /#page-wrapper -->
    </div><!-- /#wrapper -->
<?php include("includes/footer.php"); ?>