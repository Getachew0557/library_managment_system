<?php include("includes/header.php"); ?>

    <div id="wrapper">
        <?php include("includes/navigation.php"); ?> <!-- Navigation -->

        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row"> <!-- Page Heading -->
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome To Admin
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                        <div class="col-xs-6">
                        
                        <?php insertCategories() ?> <!-- Code to add categories -->
                            <!-- Form for Add Categories -->
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="cat_title">Add Book Category</label>
                                    <input type="text" name="cat_title" class="form-control" placeholder="book Category">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="add_category" class="btn btn-primary" value="Add Book Category">
                                </div>
                            </form>

                            <?php
                                // Including update_categories.php file here
                                if(isset($_GET['edit'])) {
                                    $cat_id = $_GET['edit'];
                                    include("includes/update_categories.php");
                                }
                            ?>
                        </div>

                        <div class="col-xs-6">
                            <table class="table table-responsive table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Book Category Title</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
                                    showAllCategories(); // Code to display categories
                                ?>

                                <?php
                                deleteCategories(); // Code to delete categories
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- /.row -->
            </div> <!-- /.container-fluid -->
        </div><!-- /#page-wrapper -->
    </div> <!-- /#wrapper -->
<?php include("includes/footer.php"); ?>