<?php include("includes/header.php"); ?>

    <div id="wrapper"> <!-- Navigation -->        
        <?php include("includes/navigation.php"); ?>

        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row"> <!-- Page Heading -->
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome To Dashboard <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                    </div>
                </div> <!-- /.row -->

                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class='huge'><?php echo $users_counts = recordCount('users'); ?></div>
                                        <div> Users</div>
                                    </div>
                                </div>
                            </div>
                            <a href="users.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-book fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class='huge'><?php echo $book_counts = recordCount('books'); ?></div>
                                        <div>Books</div>
                                    </div>
                                </div>
                            </div>
                            <a href="books.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class='huge'><?php echo $comments_counts = recordCount('comments'); ?></div>
                                    <div>Issue book</div>
                                    </div>
                                </div>
                            </div>
                            <a href="comments.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-list fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class='huge'><?php echo $categories_counts = recordCount('categories'); ?></div>
                                        <div>Book Categories</div>
                                    </div>
                                </div>
                            </div>
                            <a href="categories.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

                <?php
                    $book_published_counts = checkStatus('books', 'book_status', 'published');
                    $book_draft_counts  = checkStatus('books', 'book_status', 'draft');
                    $comments_unapproved_counts = checkStatus('comments', 'comment_status', 'unapproved');
                    $users_students_counts = checkStatus('users', 'user_role', 'Student');
                ?>

                <div class="row"> <!-- Google Charts -->
                    <script type="text/javascript">
                        google.charts.load('current', {'packages':['bar']});
                        google.charts.setOnLoadCallback(drawChart);

                        function drawChart() {
                            var data = google.visualization.arrayToDataTable([
                            ['Data', 'Count'],

                            <?php
                                $element_text = ['All Books', 'Active Books', 'Draft Books', 'Categories', 'Issue Comments', 'Unapproved Comments', 'Users', 'Students'];
                                $element_count = [$book_counts, $book_published_counts, $book_draft_counts, $categories_counts, $comments_counts, $comments_unapproved_counts, $users_counts, $users_students_counts];

                                for($i = 0; $i < 8; $i++) {
                                    echo "['{$element_text[$i]}'" . "," . "{$element_count[$i]}],";
                                }
                            ?>
                        ]);

                            var options = {
                                chart: {
                                    title: '',
                                    subtitle: '',
                                }
                            };

                            var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
                            chart.draw(data, google.charts.Bar.convertOptions(options));
                        }
                    </script>

                    <div id="columnchart_material" style="width: 'auto'; height: 500px;"></div>
                </div> <!-- End of Google Charts -->

            </div> <!-- /.container-fluid -->

        </div><!-- /#page-wrapper -->

    </div> <!-- /#wrapper -->
<?php include("includes/footer.php"); ?>
