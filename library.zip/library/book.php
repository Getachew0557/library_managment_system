<?php include("includes/db.php"); ?>
<?php include("includes/header.php"); ?>

    <?php include("includes/navigation.php"); ?> <!-- Navigation -->

    <div class="container"> <!-- Page Content -->
        <div class="row">
            <div class="col-md-8"> <!-- Blog Entries Column -->
            <?php 
                if(isset($_GET['p_id'])) {
                   $the_get_book_id = $_GET['p_id'];

                   $view_query = "UPDATE books set book_views_count = book_views_count + 1 WHERE book_id = $the_get_book_id";
                   $send_query = mysqli_query($connection, $view_query);

                   if(!$send_query) {
                        die("Query failed " . mysqli_error($connection));
                   }

                   if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'Admin') {
                        $query = "SELECT * FROM books WHERE book_id = $the_get_book_id";
                   } else {
                    $query = "SELECT * FROM books WHERE book_id = $the_get_book_id AND book_status = 'published'";
                   }
            
                $result = mysqli_query($connection, $query);

                if(mysqli_num_rows($result) < 1) {
                    echo "<h2 class='text-center text-danger'>No Books</h2>";
                } else {
                while($row = mysqli_fetch_array($result)) {
                    $book_id            = $row['book_id'];
                    $book_category_id   = $row['book_category_id'];
                    $book_title         = $row['book_title'];
                    $book_author        = $row['book_author'];
                    $book_date          = $row['book_date'];
                    $book_image         = $row['book_image'];
                    $book_content       = $row['book_content'];
                    $book_tags          = $row['book_tags'];
                    $book_comment_count = $row['book_comment_count'];
                    $book_status        = $row['book_status'];
            ?>

                <!-- Book View -->
                <h1 class="page-header"><a href=""><?php echo $book_title; ?></a></h1>
                <p class="lead">by <a href=""><?php echo $book_author; ?></a></p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $book_date; ?></p>
                <hr>
                <img class="img-responsive" src="images/<?php echo $book_image; ?>" alt="">
                <hr>
                <p><?php echo $book_content; ?></p>
                <hr>
            <?php } ?>

            <!-- Book Issue Comments -->
            <?php
                if(isset($_POST['create_comment'])) {
                    $the_get_post_id = $_GET['p_id'];

                    $comment_author = mysqli_real_escape_string($connection, trim($_POST['comment_author']));
                    $comment_email  = mysqli_real_escape_string($connection, trim($_POST['comment_email']));
                    $commet_content = mysqli_real_escape_string($connection, trim($_POST['comment_content']));

                    if(!empty($comment_author) && !empty($comment_email) && !empty($commet_content)) {
                        $query = "INSERT INTO comments (comment_book_id, comment_author, comment_email, 
                                comment_content, comment_status, comment_date) VALUES($the_get_book_id, 
                                '$comment_author', '$comment_email', '$commet_content', 'unapproved', now())";

                        $result = mysqli_query($connection, $query);

                        if(!$result) {
                            die("Query failed " . mysqli_error($connection));
                        }
                    } else {
                        echo "<script>alert('Fields cannot be empty')</script>";
                    }
                }
            ?>
                <!-- Comments Form -->
                <div class="well">
                    <h4>Leave a Comment:</h4>
                    <form action="" method="post" role="form">
                        <div class="form-group">
                            <label for="comment_author">Author</label>
                            <input type="text" name="comment_author" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="comment_email">Email</label>
                            <input type="email" name="comment_email" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="comment_content">Content</label>
                            <textarea name="comment_content" class="form-control" rows="3"></textarea>
                        </div>

                        <button name="create_comment" type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
                <hr>

                <!-- Posted Comments -->
                <?php 
                    $query = "SELECT * FROM comments WHERE comment_book_id = $the_get_book_id AND comment_status = 'approved' ORDER BY comment_id DESC";
                    $show_comment_based_on_approval = mysqli_query($connection, $query);

                    if (!$show_comment_based_on_approval) {
                        die("Query failed " . mysqli_error($connection));
                    }

                    while ($row = mysqli_fetch_array($show_comment_based_on_approval))  {
                        $comment_date = $row['comment_date'];
                        $comment_author = $row['comment_author'];
                        $commet_content = $row['comment_content'];
                ?>
                <!-- Comment -->
                <div class="media">
                    <a class="pull-left" href="#"><img class="media-object" src="http://placehold.it/64x64?text=IMG" alt=""></a>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $comment_author; ?>
                            <small><?php echo $comment_date; ?></small>
                        </h4>
                        <?php echo $commet_content; ?>
                    </div>
                </div>
                <?php
                    } } } else {
                        header("Location: index.php");
                    } ?>
            </div>

            <?php include("includes/sidebar.php"); ?> <!-- Blog Sidebar Widgets Column -->

        </div><!-- /.row -->
        <hr>
<?php include("includes/footer.php"); ?>