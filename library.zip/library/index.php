<?php include("includes/db.php"); ?>
<?php include("includes/header.php"); ?>

    <?php include("includes/navigation.php"); ?> <!-- Navigation -->

    <div class="container"> <!-- Page Content -->
        <div class="row">
            <div class="col-md-8"> <!-- Blog Entries Column -->
            <?php 
                $per_page = 5;

                if(isset($_GET['page'])) {
                   $page = $_GET['page'];
                } else {
                    $page = "";
                }

                if($page == "" || $page == 1) {
                    $page_1 = 0;
                } else {
                    $page_1 = ($page * $per_page) - $per_page;
                }

                if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'Admin') {
                    $book_query_count = "SELECT * FROM books";
                } else {
                    $book_query_count = "SELECT * FROM books WHERE book_status = 'published'";
                }

 
                $find_count = mysqli_query($connection, $book_query_count);
                $count = mysqli_num_rows($find_count);

                if($count < 1) {
                    echo "<h2 class='text-center text-warning'>No Books</h2>";
                } else {

                $count = ceil($count / $per_page);
            
                $query = "SELECT * FROM books LIMIT $page_1, $per_page";
                $result = mysqli_query($connection, $query);

                while($row = mysqli_fetch_array($result)) {
                    $book_id            = $row['book_id'];
                    $book_category_id   = $row['book_category_id'];
                    $book_title         = $row['book_title'];
                    $book_user        = $row['book_user'];
                    $book_date          = $row['book_date'];
                    $book_image         = $row['book_image'];
                    $book_content       = substr($row['book_content'], 0, 50);
                    $book_tags          = $row['book_tags'];
                    $book_comment_count = $row['book_comment_count'];
                    $book_status        = $row['book_status'];
            ?>

                <h2>
                    <a href="book.php?p_id=<?php echo $book_id;?>"><?php echo $book_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href=""><?php echo $book_user; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $book_date; ?></p>
                <hr>
                <a href="book.php?p_id=<?php echo $book_id; ?>">
                    <img class="img-responsive" src="images/<?php echo $book_image; ?>" alt="">
                </a>
                <hr>
                <p><?php echo $book_content; ?></p>
                <a class="btn btn-primary" href="book.php?p_id=<?php echo $book_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
            <?php
                }}
            ?>

            </div>

            <?php include("includes/sidebar.php"); ?> <!-- Blog Sidebar Widgets Column -->

        </div> <!-- /.row -->
        <hr>

        <ul class="pager">
            <?php
                for ($i = 1; $i <= $count; $i++) { 
                    if($i == $page) {
                        echo "<li><a class='active_link' href='index.php?page=$i'>$i</a></li>";
                    } else {
                        echo "<li><a href='index.php?page=$i'>$i</a></li>";
                    }
                }
            ?>
        </ul>
<?php include("includes/footer.php"); ?>