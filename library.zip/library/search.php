<?php include("includes/db.php"); ?>
<?php include("includes/header.php"); ?>

    <?php include("includes/navigation.php"); ?> <!-- Navigation -->

    <div class="container"> <!-- Page Content -->
        <div class="row">
            <div class="col-md-8"> <!-- Blog Entries Column -->
            <?php 
                if(isset($_POST['submit'])) {
                    $search = $_POST['search'];

                    $query = "SELECT * FROM books WHERE book_tags LIKE '%$search%'";
                    $result = mysqli_query($connection, $query);

                    if(!$result) {
                        die("Query failed " . mysqli_error($connection));
                    }

                    $count = mysqli_num_rows($result);

                    if($count == 0) {
                        echo "<h1 class='text-warning'>No result found.</h1>";
                    } else {
                        while($row = mysqli_fetch_array($result)) {
                            $book_id            = $row['book_id'];
                            $book_category_id   = $row['book_category_id'];
                            $book_title         = $row['book_title'];
                            $book_author        = $row['book_author'];
                            $book_date          = $row['book_date'];
                            $book_image         = $row['book_image'];
                            $book_content       = $row['book_content'];
                            $book_tags          = $row['book_tags'];
                            $book_comment_count = $row['book_comment_count'];
                            $book_status        = $row['book_status'];
            ?>
                <h2>
                    <a href="#"><?php echo $book_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href="index.php"><?php echo $book_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $book_date; ?></p>
                <hr>
                <img class="img-responsive" src="images/<?php echo $book_image; ?>" alt="">
                <hr>
                <p><?php echo $book_content; ?></p>
                <a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
            <?php } } } ?>                
                
            </div>

            <?php include("includes/sidebar.php"); ?> <!-- Blog Sidebar Widgets Column -->
        </div> <!-- /.row -->
        <hr>
<?php include("includes/footer.php"); ?>