-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 12, 2021 at 08:57 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `book_category_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `book_user` varchar(255) NOT NULL,
  `book_date` date NOT NULL,
  `book_image` text NOT NULL,
  `book_content` text NOT NULL,
  `book_tags` varchar(255) NOT NULL,
  `book_comment_count` int(11) NOT NULL,
  `book_status` varchar(255) NOT NULL,
  `book_views_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_category_id`, `book_title`, `book_author`, `book_user`, `book_date`, `book_image`, `book_content`, `book_tags`, `book_comment_count`, `book_status`, `book_views_count`) VALUES
(1, 2, 'Think and grow rich', 'Dr. Jaamac Sahal', 'muscab', '2021-07-11', '71198804_2502785136434028_382044530754453504_n.jpg', '<p>it\'s good book</p>', 'think', 0, 'published', 7),
(3, 1, 'Ugly’s Electrical References', 'Miller, Charles R.', 'muscab', '2021-07-12', 'a1.jpg', 'good', 'algorithm', 0, 'published', 0),
(4, 1, 'Dewalt Electrical Licensing', 'Holder, Ray', 'lukman', '2021-07-12', 'dewalt.jpeg', 'good book for electrical engineers', 'crkt', 0, 'published', 2),
(5, 1, 'Mike Holt’s Electrical Study Guide Textbook', 'Mike Holt', 'lukman', '2021-07-12', '', 'Covers all the essential electrical topics (excellent electrical training book)', 'exam book', 0, 'published', 0),
(6, 3, 'The Magic of Reality: How We Know What’s Really True', 'richard dawkins', 'lukman', '2021-07-12', 'richard.jpeg', 'Dawkins shows us the most common myths behind tsunamis, evolution and the universe followed by letting us know the real truth.', 'science', 0, 'published', 0),
(7, 3, 'The Gene: An Intimate History', 'Siddhartha mukherjee', 'lukman', '2021-07-12', 'gene.jpeg', '<p><span style=\"color: #222222; font-family: \'Open Sans\', sans-serif; font-size: 18px;\">shows us how gene research began, what we&rsquo;ve uncovered and what the future holds.</span></p>', 'science', 0, 'published', 0),
(8, 4, 'THE ZERO SUGAR DIET', 'David Zinczenko with Stephen Perrine', 'lukman', '2021-07-12', 'sugar.jpeg', '<p>&nbsp;</p>\r\n<p class=\"css-14lubdp\" style=\"margin: 0.25rem 0px 0.4375rem; padding: 0px; border: 0px; text-size-adjust: 100%; font-style: inherit; font-variant: inherit; font-weight: 500; font-stretch: inherit; font-size: 0.875rem; line-height: 1.1875rem; font-family: nyt-imperial, georgia, \'times new roman\', times, serif; vertical-align: baseline; color: #333333; -webkit-font-smoothing: antialiased;\">A 14-day plan for cutting out all sugar and using protein and fiber to slow the absorption of carbohydrates.</p>', 'health', 0, 'published', 0),
(9, 1, 'BEING MORTAL', 'Atul gawande', 'lukman', '2021-07-12', 'mortal.jpeg', '<p>the surgeon new yorker&nbsp;</p>', 'health', 0, 'published', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Engineering'),
(2, 'Fiction'),
(3, 'Science'),
(4, 'Health');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `comment_book_id` int(11) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_book_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(1, 1, 'muscab', 'muscab9494@gmail.com', 'mashaa allah', 'approved', '2021-07-11'),
(2, 2, 'Miller charles', 'axmedmukhtaar70@gmail.com', 'its amazing book', 'unapproved', '2021-07-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) NOT NULL DEFAULT '$2y$10$iusesomecrazystrings22'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randSalt`) VALUES
(1, 'muscab', '$2y$12$28XsvoLJ4WKtaR9JHxlH/.cMKGUAX/aP66RxJPJtpCH1EKUlpYJaO', '', '', 'muscab9494@gmail.com', '', 'Admin', '$2y$10$iusesomecrazystrings22'),
(2, 'ahmed', '$2y$12$28XsvoLJ4WKtaR9JHxlH/.cMKGUAX/aP66RxJPJtpCH1EKUlpYJaO', 'ahmed', 'mahad', 'axmedmukhtaar70@gmail.com', 'ahmed', 'Student', '$2y$10$iusesomecrazystrings22'),
(3, 'lukman', '$2y$12$M5iVwsFA3HDyKXxYAoDFhuGtg153OkhIb/Ake.Mo7m/97/OKnKAKm', 'lukman', 'abdikadir', 'axmedmukhtaar70@gmail.com', 'a1.jpg', 'Admin', '$2y$10$iusesomecrazystrings22'),
(4, 'abdi', '$2y$12$4sffqcC6zinRIxjg9gH9sOuFC9134OFMvyezKToPi8zDucFWaU26y', 'abdi', 'mahad', 'abdi@gmail.com', 'a1.jpg', 'Admin', '$2y$10$iusesomecrazystrings22'),
(5, 'getch', '$2y$12$z/TmIxw2nagyAXNwrax.q.XZyXAsUFsKfz2EhJI1wNt.H4DIKtoDm', '', '', 'getch1234@gmail.com', '', 'Student', '$2y$10$iusesomecrazystrings22');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `session`, `time`) VALUES
(1, 'c75bn24afkr4fvsj40sdn50qpu', 1625957457),
(2, 'pa48apb1d5ppvi9p8apii464i5', 1626115518),
(3, 'apb5g9vgn1i3b51gal3ish6oer', 1626116220);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
