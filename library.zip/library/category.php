<?php include("includes/db.php"); ?>
<?php include("includes/header.php"); ?>

    <?php include("includes/navigation.php"); ?> <!-- Navigation -->

    <div class="container"> <!-- Page Content -->
        <div class="row">
            <div class="col-md-8"> <!-- Blog Entries Column -->
            <?php 
                if(isset($_GET['category'])) {
                    $the_get_category_id = $_GET['category'];

                    if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'Admin') {
                        $query = "SELECT * FROM books WHERE book_category_id = $the_get_category_id";
                    } else {
                        $query = "SELECT * FROM books WHERE book_category_id = $the_get_category_id AND book_status = 'published'";
                    }
                
                $result = mysqli_query($connection, $query);

                if(mysqli_num_rows($result) < 1) {
                    echo "<h2 class='text-center text-danger'>No Books</h2>";
                } else {

                while($row = mysqli_fetch_array($result)) {
                    $book_id            = $row['book_id'];
                    $book_category_id   = $row['book_category_id'];
                    $book_title         = $row['book_title'];
                    $book_author        = $row['book_author'];
                    $book_date          = $row['book_date'];
                    $book_image         = $row['book_image'];
                    $book_content       = substr($row['book_content'], 0, 50);
                    $book_tags          = $row['book_tags'];
                    $book_comment_count = $row['book_comment_count'];
                    $book_status        = $row['book_status'];
            ?>

                <h2>
                    <a href="book.php?p_id=<?php echo $book_id;?>"><?php echo $book_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href="index.php"><?php echo $book_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $book_date; ?></p>
                <hr>
                <img class="img-responsive" src="images/<?php echo $book_image; ?>" alt="">
                <hr>
                <p><?php echo $book_content; ?></p>
                <a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
            <?php
                 } }} else {
                    header("Location: index.php");
                }
            ?>
            </div>
            <?php include("includes/sidebar.php"); ?> <!-- Blog Sidebar Widgets Column -->

        </div> <!-- /.row -->
        <hr>
<?php include("includes/footer.php"); ?>